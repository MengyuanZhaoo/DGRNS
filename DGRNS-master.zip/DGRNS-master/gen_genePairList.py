from dataPreprocess import *
import os
#input
gene_expression_path = 'E:/Papers/20201109-LEAP/LEAP-CNN/scRNA-Seq/mHSC-GM/ExpressionDataOrdered.csv'
gene_order_path = 'E:/Papers/20201109-LEAP/LEAP-CNN/scRNA-Seq/mHSC-GM/GeneOrdering.csv'
gold_network_path='E:/Papers/20201109-LEAP/LEAP-CNN/Gold-network/mouse/STRING-network-unique.csv'
#output
filtered_path= 'E:/Papers/20201109-LEAP/LEAP-CNN/1000genes/FilteredGoldNetwork/'
FGN_file_name= 'mHSC-GM-STRING-FGN.csv'
rank_path= 'E:/Papers/20201109-LEAP/LEAP-CNN/1000genes/'
Rank_file_name='mHSC-GM-1000genes-STRING-rank.csv'
genePairList_path= 'E:/Papers/20201109-LEAP/LEAP-CNN/1000genes/GenePairList/'
GPL_file_name= 'mHSC-GM-STRING-GPL.csv'
Rank_num=1000

origin_expression_record,cells=get_origin_expression_data(gene_expression_path)
Expression_gene_num=len(origin_expression_record)
Expression_cell_num=len(cells)

low_express_gene_list=get_low_express_gene(origin_expression_record,len(cells))
print(str(len(low_express_gene_list))+' genes in low expression.')
for gene in low_express_gene_list:
    origin_expression_record.pop(gene)


if not os.path.isdir(rank_path):
    os.makedirs(rank_path)
rank_list,significant_gene_list = get_gene_ranking(gene_order_path, low_express_gene_list,Rank_num, rank_path + Rank_file_name, False)

gold_pair_record, gold_score_record ,unique_gene_list= get_filtered_gold(gold_network_path, rank_list,rank_path+Rank_file_name,True)
#If origin gold file, generate filtered gold file
if not os.path.isdir(filtered_path):
    os.makedirs(filtered_path)
generate_filtered_gold( gold_pair_record, gold_score_record,filtered_path + FGN_file_name)

#generate gene pair list
if not os.path.isdir(rank_path):
    os.makedirs(rank_path)
get_gene_pair_list(unique_gene_list, gold_pair_record, gold_score_record, genePairList_path + GPL_file_name)



