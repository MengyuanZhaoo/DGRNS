from __future__ import print_function
import keras
from keras.models import Sequential, Model
from keras.layers import Dense, Dropout, Activation, Flatten, Input, concatenate, Lambda, Reshape, Multiply
from keras.layers import LSTM, Conv2D, MaxPooling2D,GRU,Bidirectional,SimpleRNN
# from keras.layers.convolutional import Convolution2D, MaxPooling2D
from keras.optimizers import SGD
from keras import backend as K
from keras.callbacks import EarlyStopping, ModelCheckpoint
import tensorflow as tf
import os, sys
import numpy as np
import matplotlib.pyplot as plt
from keras.utils import plot_model
from sklearn import metrics, preprocessing
import warnings

warnings.filterwarnings("ignore")


def load_data_TF2(indel_list, data_path):
    import numpy as np
    xxdata_list = []
    yydata = []
    count_set = [0]
    count_setx = 0
    for i in indel_list:  # len(h_tf_sc)):
        xdata = np.load(data_path + '/Nxdata_tf' + str(i) + '.npy')
        ydata = np.load(data_path + '/ydata_tf' + str(i) + '.npy')
        for k in range(len(ydata)):
            xxdata_list.append(xdata[k, :, :, :])
            yydata.append(ydata[k])
        count_setx = count_setx + len(ydata)
        count_set.append(count_setx)
        print(i, len(ydata))
    yydata_array = np.array(yydata)
    yydata_x = yydata_array.astype('int')
    print(np.array(xxdata_list).shape)
    return ((np.array(xxdata_list), yydata_x, count_set))


####################################### parameter settings
batch_size = 1024  # mini batch for training
num_classes = 2  # categories of labels
epochs = 100

model_name = 'final_model.h5'
data_path = 'E:/Papers/DGRNS/1000genes/mHSC-E-Nonspecific-LogPearson/WindowSize441-TF5-Target5-Lag64/Matrix'
model_save_dir = 'E:/Papers/DGRNS/1000genes/mHSC-E-Nonspecific-LogPearson/WindowSize441-TF5-Target5-Lag64/DGENS-model/'
png_file='E:/Papers/DGRNS/1000genes/mHSC-E-Nonspecific-LogPearson/WindowSize441-TF5-Target5-Lag64/LSTM128&T32-32-model/DGRNS.png'

matrix_data = np.load(data_path + '/matrix.npy')
label_data = np.load(data_path + '/label.npy')
gene_pair = np.load(data_path + '/gene_pair.npy')
num_pairs = len(label_data)
index_array = np.arange(0, num_pairs)
single_fold = num_pairs // 3
fold_list = [[0, single_fold], [single_fold, 2 * single_fold], [2 * single_fold, num_pairs]]
# three fold cross validation
for test_indel in range(0, 3):
    save_dir = os.path.join(model_save_dir +
                            str(test_indel) + 'saved_models_e' + str(epochs))  ## the result folder
    if not os.path.isdir(save_dir):
        os.makedirs(save_dir)

    test_range = fold_list[test_indel]
    train_data_list_cnn = []
    train_label_list = []
    test_data_list_cnn = []
    test_label_list = []
    for index_pair in range(num_pairs):
        if test_range[0] <= index_pair < test_range[1]:
            test_data_list_cnn.append(matrix_data[index_pair, :, :, :])
            test_label_list.append(label_data[index_pair])
        else:
            train_data_list_cnn.append(matrix_data[index_pair, :, :, :])
            train_label_list.append(label_data[index_pair])

    x_train = np.array(train_data_list_cnn)
    y_train = np.array(train_label_list)
    x_test = np.array(test_data_list_cnn)
    y_test = np.array(test_label_list)
    print(y_train.shape, 'y_train samples')
    print(y_test.shape, 'y_test samples')
    print(x_train.shape, 'x_train samples')
    print(x_test.shape, 'x_test samples')
    col_x_train=x_train.swapaxes(1,2)
    col_x_test=x_test.swapaxes(1,2)

    # Model structure
    input = Input(shape=x_train.shape[1:], name='input')

    # RNN section
    # SimpleRNN
    # with tf.name_scope('rnn_section'):
    #     rnn_input = Reshape((x_train.shape[1], x_train.shape[2]))(input)
    #     rnn_output = SimpleRNN(128, dropout=0.2, return_sequences=True)(rnn_input)

    # LSTM
    # with tf.name_scope('lstm_section'):
    #     lstm_input = Reshape((x_train.shape[1], x_train.shape[2]))(input)
    #     rnn_output = LSTM(128, dropout=0.2, return_sequences=True)(lstm_input)

    # GRU
    with tf.name_scope('gru_section'):
        gru_input = Reshape((x_train.shape[1], x_train.shape[2]))(input)
        rnn_output = GRU(128, dropout=0.2, return_sequences=True)(gru_input)

    # BiGRU
    # with tf.name_scope('bigru_section'):
    #     bigru_input = Reshape((x_train.shape[1], x_train.shape[2]))(input)
    #     rnn_output = Bidirectional(GRU(128, dropout=0.2, return_sequences=True))(bigru_input)



    with tf.name_scope('cnn_section'):
        cnn_input=Reshape((64,128,1))(rnn_output)
        layer1_output = Conv2D(32, (3,3), padding='same', input_shape=(64,128,1), activation='relu')(cnn_input)
        layer2_output = Dropout(0.25)(
            MaxPooling2D(pool_size=(2,2))(Conv2D(32, (3,3), activation='relu')(layer1_output)))

        cnn_output = Dropout(0.5)(Dense(512, activation='relu')(Flatten()(layer2_output)))
        output = Dense(1, activation='sigmoid')(Dense(128)(cnn_output))

    model = Model(inputs=input, outputs=output)
    sgd = SGD(lr=0.02, decay=1e-6, momentum=0.9, nesterov=True)
    model.compile(optimizer=sgd, loss='binary_crossentropy', metrics=['accuracy'])

    plot_model(model, to_file=png_file, show_shapes=True)
    model.summary()
    checkpoint2 = ModelCheckpoint(filepath=save_dir + '/best_model.hdf5', monitor='val_acc', verbose=1,
                                  save_best_only=True, mode='auto', save_weights_only=False, period=1)
    callbacks_list = [checkpoint2]
    history = model.fit(
        x_train,
        y_train,
        batch_size=batch_size,
        epochs=epochs,
        validation_split=0.2,
        shuffle=True,
        callbacks=callbacks_list,
    )

    # x_test=col_x_test
    # Save model and weights
    model_path = os.path.join(save_dir, model_name)
    model.save(model_path)
    print('Saved trained model at %s ' % model_path)
    # Score trained model.
    scores = model.evaluate(x_test, y_test, verbose=1)
    print('Test loss:', scores[0])
    print('Test accuracy:', scores[1])
    y_predict = model.predict(x_test)
    np.save(save_dir + '/end_y_test.npy', y_test)
    np.save(save_dir + '/end_y_predict.npy', y_predict)
    ############################################################################## plot training process
    plt.figure(figsize=(10, 6))
    plt.subplot(1, 2, 1)
    plt.plot(history.history['acc'])
    plt.plot(history.history['val_acc'])
    plt.title('model accuracy')
    plt.ylabel('accuracy')
    plt.xlabel('epoch')
    plt.grid()
    plt.legend(['train', 'val'], loc='upper left')
    plt.subplot(1, 2, 2)
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title('model loss')
    plt.ylabel('loss')
    plt.xlabel('epoch')
    plt.legend(['train', 'val'], loc='upper left')
    plt.grid()
    plt.savefig(save_dir + '/end_result.pdf')

    ###############################################################  evaluation without consideration of data separation
    plt.figure(figsize=(10, 6))
    fpr, tpr, thresholds = metrics.roc_curve(y_test, y_predict, pos_label=1)
    auc = np.trapz(tpr, fpr)
    plt.plot(fpr, tpr, label='AUROC = %0.5f)' % auc)
    plt.grid()
    plt.plot([0, 1], [0, 1])
    plt.title('ROC curve')
    plt.xlabel('FP')
    plt.ylabel('TP')
    plt.ylim([0, 1])
    plt.xlim([0, 1])
    plt.legend(loc="lower right")
    print('AUC:', auc)
    plt.savefig(save_dir + '/AUCofTest.pdf')

    precision, recall, thresholds_PR = metrics.precision_recall_curve(y_test, y_predict)
    AUPR = metrics.auc(recall, precision)
    pr_curve = plt.figure(1)
    plt.plot(precision, recall, label='Area Under the Curve (AUPR = %0.5f)' % AUPR)
    plt.title('PR curve')
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.legend(loc="lower right")
    plt.ylim([0, 1])
    plt.xlim([0, 1])
    plt.savefig(save_dir + '/AUPRofTest.pdf')
    print("AUPR:", AUPR)
