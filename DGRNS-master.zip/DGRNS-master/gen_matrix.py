import numpy as np
import os
from dataPreprocess import *
import csv
import pandas as pd

def cal_pccs(x, y, n):
    """
    warning: data format must be narray
    :param x: Variable 1
    :param y: The variable 2
    :param n: The number of elements in x
    :return: pccs
    """
    sum_xy = np.sum(np.sum(x*y))
    sum_x = np.sum(np.sum(x))
    sum_y = np.sum(np.sum(y))
    sum_x2 = np.sum(np.sum(x*x))
    sum_y2 = np.sum(np.sum(y*y))
    pcc = (n*sum_xy-sum_x*sum_y)/np.sqrt((n*sum_x2-sum_x*sum_x)*(n*sum_y2-sum_y*sum_y))
    return pcc


# input
gene_pair_list_path='E:/Papers/20201109-LEAP/LEAP-CNN/1000genes/GenePairList/mHSC-GM-STRING-GPL.csv'
gene_expression_path='E:/Papers/20201109-LEAP/LEAP-CNN/scRNA-Seq/mHSC-GM/ExpressionDataOrdered.csv'
# output
save_dir = 'E:/Papers/20201109-LEAP/LEAP-CNN/1000genes/mHSC-GM-STRING-LogPearson/WindowSize259-TF5-Target5-Lag64/Matrix'
if not os.path.isdir(save_dir):
    os.makedirs(save_dir)

Window_size=259
TF_Gap=5
Target_Gap=5
#Gap=10
Max_lag=64

# Load gene expression data
origin_expression_record,cells=get_normalized_expression_data(gene_expression_path)
timepoints=len(cells)
gene_pair_label = []
f_genePairList=open(gene_pair_list_path)### read the gene pair and label file
gene_pair_list = list(csv.reader(f_genePairList))[1:]
f_genePairList.close()

# Generate Pearson matrix
label_list=[]
pair_list=[]
total_matrix=[]
'''
#missing value=0
for i in range(len(gene_pair_list)):
    print ('Generating matrix of gene pair '+str(i))
    tf_name,target_name,label = gene_pair_list[i][0],gene_pair_list[i][1],gene_pair_list[i][2]
    label_list.append(int(label))
    pair_list.append(tf_name + ',' + target_name)

    # K= ((timepoints - Window_size) // Gap + 1)*2
    # ave_matrix = np.zeros((K, K))
    tf_data=origin_expression_record[tf_name]
    target_data = origin_expression_record[target_name]

    #calculate matrix of one gene pair
    pair_matrix = []
    for tf_window_left in range(0,timepoints-Window_size+1,Gap):
        tf_window_data = tf_data[tf_window_left:tf_window_left + Window_size]
        single_tf_list=[]
        tf_pd=pd.Series(tf_window_data)
        #if tf_window_data==[0 for i in range(0,Window_size)]:
        if (tf_window_data == np.zeros(Window_size)).all():
            pair_matrix = np.vstack((pair_matrix, np.zeros(Max_lag)))
            continue
        for lag in range(0,Max_lag):
            target_window_left=tf_window_left+lag*Gap
            if target_window_left + Window_size<timepoints:
                target_window_data = target_data[target_window_left:target_window_left + Window_size]
            elif target_window_left < timepoints <= target_window_left + Window_size:
                target_window_data = target_data[target_window_left:]
                #target_window_data.extend([0 for i in range(Window_size - (timepoints - target_window_left))])
                target_window_data=np.hstack((target_window_data,np.zeros(Window_size - (timepoints - target_window_left))))
            elif target_window_left>=timepoints:
                #target_window_data=[0 for i in range(0,Window_size)]
                target_window_data=np.zeros(Window_size)
            else:
                exit('Slide window error!')
            target_pd = pd.Series(target_window_data)
            # calculate PCC
            #if target_window_data==[0 for i in range(0,Window_size)]:
            if (target_window_data == np.zeros(Window_size)).all():
                single_tf_list.append(0)
            else:
                single_tf_list.append(tf_pd.corr(target_pd, method="pearson"))

        if pair_matrix==[]:
            pair_matrix=np.array(single_tf_list)
        else:
            pair_matrix=np.vstack((pair_matrix, np.array(single_tf_list)))
    total_matrix.append(pair_matrix.copy())
'''

'''
#missing value:return head
for i in range(len(gene_pair_list)):
    print ('Generating matrix of gene pair '+str(i))
    tf_name,target_name,label = gene_pair_list[i][0],gene_pair_list[i][1],gene_pair_list[i][2]
    label_list.append(int(label))
    pair_list.append(tf_name + ',' + target_name)

    tf_data=origin_expression_record[tf_name]
    target_data = origin_expression_record[target_name]

    #calculate matrix of one gene pair
    pair_matrix = []
    for tf_window_left in range(0,timepoints-Window_size+1,Gap):
        tf_window_data = tf_data[tf_window_left:tf_window_left + Window_size]
        single_tf_list=[]
        tf_pd=pd.Series(tf_window_data)
        if (tf_window_data == np.zeros(Window_size)).all():
            #pair_matrix = np.vstack((pair_matrix, np.zeros(Max_lag)))
            exit('tf data error!')
            continue
        for lag in range(0,Max_lag):
            target_window_left=tf_window_left+lag*Gap
            if target_window_left + Window_size<timepoints:
                target_window_data = target_data[target_window_left:target_window_left + Window_size]
            elif target_window_left < timepoints <= target_window_left + Window_size:
                # target_window_data = target_data[target_window_left:]
                # target_window_data=np.hstack((target_window_data,np.zeros(Window_size - (timepoints - target_window_left))))
                target_window_data=np.hstack((target_data[target_window_left:],target_data[:Window_size - (timepoints - target_window_left)]))
            elif target_window_left>=timepoints:
                #target_window_data=[0 for i in range(0,Window_size)]
                #target_window_data=np.zeros(Window_size)
                target_window_data =target_data[target_window_left-timepoints:target_window_left-timepoints+Window_size]
            else:
                exit('Slide window error!')
            target_pd = pd.Series(target_window_data)
            # calculate PCC
            #if target_window_data==[0 for i in range(0,Window_size)]:
            if (target_window_data == np.zeros(Window_size)).all():
                single_tf_list.append(0)
            else:
                single_tf_list.append(tf_pd.corr(target_pd, method="pearson"))

        if pair_matrix==[]:
            pair_matrix=np.array(single_tf_list)
        else:
            pair_matrix=np.vstack((pair_matrix, np.array(single_tf_list)))
    total_matrix.append(pair_matrix.copy())
'''

#without missing value: based on target gene
for i in range(len(gene_pair_list)):
    print ('Generating matrix of gene pair '+str(i))
    tf_name,target_name,label = gene_pair_list[i][0],gene_pair_list[i][1],gene_pair_list[i][2]
    label_list.append(int(label))
    pair_list.append(tf_name + ',' + target_name)

    tf_data=origin_expression_record[tf_name]
    target_data = origin_expression_record[target_name]

    #calculate matrix of one gene pair
    pair_matrix = []
    for tf_window_left in range(0,timepoints-Window_size+1,TF_Gap):
        if tf_window_left+Window_size+Target_Gap*(Max_lag-1)>timepoints:
            break
        tf_window_data = tf_data[tf_window_left:tf_window_left + Window_size]
        single_tf_list=[]
        tf_pd=pd.Series(tf_window_data)
        if (tf_window_data == np.zeros(Window_size)).all():
            #pair_matrix = np.vstack((pair_matrix, np.zeros(Max_lag)))
            exit('tf data error!')
            continue
        for lag in range(0,Max_lag):
            target_window_left=tf_window_left+lag*Target_Gap
            if target_window_left + Window_size>timepoints:
                exit('Planning error!')
            target_window_data = target_data[target_window_left:target_window_left + Window_size]
            target_pd = pd.Series(target_window_data)
            # calculate PCC
            pcc=tf_pd.corr(target_pd, method="pearson")
            if np.isnan(pcc) or np.isinf(pcc):
                single_tf_list.append(0.0)
                print('Replace Nan or inf with 0.')
            else:
                single_tf_list.append(pcc)
        if pair_matrix==[]:
            pair_matrix=np.array(single_tf_list)
        else:
            pair_matrix=np.vstack((pair_matrix, np.array(single_tf_list)))
    total_matrix.append(pair_matrix.copy())




if (len(total_matrix)>0):
    total_matrix = np.array(total_matrix)[:, :, :, np.newaxis]
else:
    exit('Save eror.')
np.save(save_dir +'/matrix.npy', total_matrix)
np.save(save_dir+'/label.npy', np.array(label_list))
np.save(save_dir+'/gene_pair.npy', np.array(pair_list))
print('PCC matrix generation finish.')