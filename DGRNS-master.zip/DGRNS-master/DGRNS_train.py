from __future__ import print_function
import keras
from keras.models import Sequential, Model
from keras.layers import Dense, Dropout, Activation, Flatten, Input, concatenate, Lambda, Reshape, Multiply
from keras.layers import LSTM, Conv2D, MaxPooling2D,GRU,Bidirectional,SimpleRNN
from keras.optimizers import SGD
from keras import backend as K
from keras.callbacks import EarlyStopping, ModelCheckpoint
import tensorflow as tf
import os, sys
import numpy as np
import matplotlib.pyplot as plt
from keras.utils import plot_model
from sklearn import metrics
from sklearn.model_selection import train_test_split
import warnings
import csv
import time

warnings.filterwarnings("ignore")

def load_index(file):
    with open(file,'r') as f:
        csv_r=list(csv.reader(f,delimiter='\n'))
    return np.array(csv_r).flatten().astype(int)

def auroc(y_true, y_pred):
    return tf.py_func(metrics.roc_auc_score, (y_true, y_pred), tf.double)

def aupr_cal(y_true, y_pred):
    precision, recall, thresholds_PR = metrics.precision_recall_curve(y_true, y_pred)
    return metrics.auc(recall, precision)

def aupr(y_true, y_pred):
    # precision, recall, thresholds_PR = metrics.precision_recall_curve(y_true, y_pred)
    # AUPR = metrics.auc(recall, precision)
    return tf.py_func(aupr_cal, (y_true, y_pred), tf.double)


####################################### parameter settings
batch_size = 1024  # mini batch for training
num_classes = 2  # categories of labels
epochs = 50

model_name = 'final_model.h5'
# data_path = 'E:/Papers/20210124-DGRNS/500genes/mHSC-E-Nonspecific-LogPearson/WindowSize131-TF10-Target10-Lag32/FullMatrix_TF'
# model_save_dir = 'E:/Papers/20210124-DGRNS/500genes/mHSC-E-Nonspecific-LogPearson/WindowSize131-TF10-Target10-Lag32/DGRNS-model-Independent/'

dir='E:/Papers/20210124-DGRNS/500genes/mHSC-E-Nonspecific-LogPearson/WindowSize121-TF5-Target5-Lag96/'
data_path = dir+'FullMatrix_TF'
model_save_dir =dir+'DGRNS-model-Independent/'
if not os.path.isdir(model_save_dir):
    os.makedirs(model_save_dir)

matrix_data = np.load(data_path + '/matrix.npy')
label_data = np.load(data_path + '/label.npy')
num_pairs = len(label_data)

# train_index=load_index(data_path+'/train_index.txt')
# val_index=load_index(data_path+'/val_index.txt')
# test_index=load_index(data_path+'/test_index.txt')

index_data_path='E:/Papers/20210124-DGRNS/500genes/mHSC-E-Nonspecific-LogPearson/WindowSize441-TF5-Target5-Lag64/FullMatrix_TF'
train_index=load_index(index_data_path+'/train_index.txt')
val_index=load_index(index_data_path+'/val_index.txt')
test_index=load_index(index_data_path+'/test_index.txt')

# split training and validation systematically
# train_val_index=np.append(train_index,val_index)
# train_val_data=matrix_data[train_val_index]
# train_val_label=label_data[train_val_index]
# x_train, x_val,y_train, y_val = train_test_split(train_val_data, train_val_label, test_size=0.2, random_state=1)


x_train=matrix_data[train_index]
y_train=label_data[train_index]
x_val=matrix_data[val_index]
y_val=label_data[val_index]
x_test=matrix_data[test_index]
y_test=label_data[test_index]

print(x_train.shape, 'x_train samples')
print(x_val.shape, 'x_val samples')
print(x_test.shape, 'x_test samples')
print(y_train.shape, 'y_train samples')
print(y_val.shape, 'y_val samples')
print(y_test.shape, 'y_test samples')

#calculate running time
start=time.clock()

# Model structure
input = Input(shape=x_train.shape[1:], name='input')
# RNN section
# SimpleRNN
# with tf.name_scope('rnn_section'):
#     rnn_input = Reshape((x_train.shape[1], x_train.shape[2]))(input)
#     rnn_output = SimpleRNN(128, dropout=0.2, return_sequences=True)(rnn_input)

# LSTM
# with tf.name_scope('lstm_section'):
#     lstm_input = Reshape((x_train.shape[1], x_train.shape[2]))(input)
#     rnn_output = LSTM(128, dropout=0.2, return_sequences=True)(lstm_input)

# GRU
with tf.name_scope('gru_section'):
    gru_input = Reshape((x_train.shape[1], x_train.shape[2]))(input)
    rnn_output = GRU(128, dropout=0.2, return_sequences=True)(gru_input)

# BiGRU
# with tf.name_scope('bigru_section'):
#     bigru_input = Reshape((x_train.shape[1], x_train.shape[2]))(input)
#     rnn_output = Bidirectional(GRU(128, dropout=0.2, return_sequences=True))(bigru_input)



with tf.name_scope('cnn_section'):
    # cnn_input = input
    cnn_input=Reshape((x_train.shape[1],128,1))(rnn_output)
    # cnn_input=tf.expand_dims(rnn_output, -1)
    layer1_output = Conv2D(32, (3,3), padding='same', input_shape=(64,128,1), activation='relu')(cnn_input)
    layer2_output = Dropout(0.25)(
        MaxPooling2D(pool_size=(2,2))(Conv2D(32, (3,3), activation='relu')(layer1_output)))

    # layer3_output = Conv2D(64, (3,3), padding='same', activation='relu')(layer2_output)
    # layer4_output = Dropout(0.25)(
    #     MaxPooling2D(pool_size=(2,2))(Conv2D(64, (3,3), activation='relu')(layer3_output)))
    #
    # layer5_output = Conv2D(128, (5,5), activation='relu')(layer4_output)
    # layer6_output = Dropout(0.25)(
    #     MaxPooling2D(pool_size=(2,2))(Conv2D(128, (5,5), activation='relu')(layer5_output)))

    cnn_output = Dropout(0.5)(Dense(512, activation='relu')(Flatten()(layer2_output)))
    output = Dense(1, activation='sigmoid')(Dense(128)(cnn_output))

# output=Dense(1, activation='sigmoid')(rnn_output)
model = Model(inputs=input, outputs=output)
sgd = SGD(lr=0.02, decay=1e-6, momentum=0.9, nesterov=True)
model.compile(optimizer=sgd, loss='binary_crossentropy', metrics=['accuracy'])
# model.compile(optimizer=sgd, loss='binary_crossentropy', metrics=['accuracy',auroc,aupr])

model.summary()
# early_stopping = keras.callbacks.EarlyStopping(monitor='val_acc', patience=50, verbose=0, mode='auto')
checkpoint = ModelCheckpoint(filepath=model_save_dir + 'best_model.hdf5', monitor='val_acc', verbose=1,
                              save_best_only=True, mode='auto', save_weights_only=False, period=1)
callbacks_list = [checkpoint]

history = model.fit(
    x_train,
    y_train,
    validation_data=(x_val,y_val),
    batch_size=batch_size,
    epochs=epochs,
    # validation_split=0.2,
    shuffle=True,
    callbacks=callbacks_list,
)


# Save model and weights
model_path = os.path.join(model_save_dir, model_name)
model.save(model_path)
print('Saved trained model at %s ' % model_path)

# Score trained model.
# scores = model.evaluate(x_test, y_test, verbose=1)
# print('Test loss:', scores[0])
# print('Test accuracy:', scores[1])
y_predict = model.predict(x_test)
np.save(model_save_dir + 'y_test.npy', y_test)
np.save(model_save_dir + 'y_predict.npy', y_predict)

end=time.clock()
print('Running time:'+str(end-start))

############################################################################## plot training process
plt.figure(figsize=(10, 6))
plt.subplot(1, 2, 1)
plt.plot(history.history['acc'])
plt.plot(history.history['val_acc'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.grid()
plt.legend(['train', 'val'], loc='upper left')
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'val'], loc='upper left')
plt.grid()
plt.savefig(model_save_dir + 'train_process.pdf')

###############################################################  evaluation without consideration of data separation
plt.figure(figsize=(10, 6))
fpr, tpr, thresholds = metrics.roc_curve(y_test, y_predict, pos_label=1)
auc = metrics.auc(fpr, tpr)
plt.plot(fpr, tpr, label='AUROC = %0.5f)' % auc)
plt.grid()
plt.plot([0, 1], [0, 1])
plt.title('ROC curve')
plt.xlabel('FP')
plt.ylabel('TP')
plt.ylim([0, 1])
plt.xlim([0, 1])
plt.legend(loc="lower right")
print('AUC in figure:', auc)
plt.savefig(model_save_dir + 'AUCofTest.pdf')

precision, recall, thresholds_PR = metrics.precision_recall_curve(y_test, y_predict)
AUPR = metrics.auc(recall, precision)
pr_curve = plt.figure(1)
plt.plot(precision, recall, label='Area Under the Curve (AUPR = %0.5f)' % AUPR)
plt.title('PR curve')
plt.xlabel("Recall")
plt.ylabel("Precision")
plt.legend(loc="lower right")
plt.ylim([0, 1])
plt.xlim([0, 1])
plt.savefig(model_save_dir + 'AUPRofTest.pdf')
print("AUPR in figure:", AUPR)
