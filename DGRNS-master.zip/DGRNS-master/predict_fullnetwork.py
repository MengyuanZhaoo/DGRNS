# Usage: python predict_no_y.py  number_of_separation NEPDF_pathway model_pathway
# command line in developer's linux machine :
# python predict_no_y.py  9 /home/yey3/cnn_project/code3/NEPDF_data 3  /home/yey3/cnn_project/code3/trained_model/models/KEGG_keras_cnn_trained_model_shallow2.h5
from __future__ import print_function
import keras
from keras.preprocessing.image import ImageDataGenerator
from keras.models import Sequential
from keras.models import load_model
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import Conv2D, MaxPooling2D
from keras.optimizers import SGD
from keras.callbacks import EarlyStopping,ModelCheckpoint
import openpyxl
from keras import backend as K
import os,sys
import numpy as np
import matplotlib.pyplot as plt
from sklearn import metrics
import itertools
import csv

def get_filtered_expression_data(gene_expression_path,gene_name_list):
    f_expression = open(gene_expression_path)
    expression_reader = list(csv.reader(f_expression))

    expression_record = {}
    Num_genes = 0
    for single_expression_reader in expression_reader[1:]:
        if single_expression_reader[0] in gene_name_list:
            if single_expression_reader[0] not in expression_record:
                expression_record[single_expression_reader[0]] = np.array(list(map(float, single_expression_reader[1:])))
    return expression_record

def load_data(data_path):
    xxdata_list = []
    yydata = []
    zzdata = []
    matrix_array=np.load(data_path+'/matrix.npy')
    label_array=np.load(data_path+'/label.npy')
    pair_array=np.load(data_path+'/gene_pair.npy')
    print(matrix_array.shape)



    # xdata = np.load(data_path+'/matrix.npy')
    # ydata = np.load(data_path+'/label.npy')
    # zdata=np.load(data_path+'/zdata_tf' + str(i) + '.npy')
    #     for k in range(len(ydata)):
    #         xxdata_list.append(xdata[k,:,:])
    #         yydata.append(ydata[k])
    #         zzdata.append(zdata[k])
    #     count_setx = count_setx + len(ydata)
    #     count_set.append(count_setx)
    #     print (i,len(ydata))
    # yydata_array = np.array(yydata)
    # yydata_x = yydata_array.astype('int')
    # print (np.array(xxdata_list).shape)
    return(matrix_array,label_array,pair_array)

def predict(matrix_path,model_path,save_dir,fold_index):

    (x_test, y_test,pair_test) = load_data(matrix_path)
    print(x_test.shape, 'x_test samples')
    model = load_model(model_path)
    # Final evaluation of the model
    if not os.path.isdir(save_dir):
        os.makedirs(save_dir)
    print ('load model and predict')
    y_predict = model.predict(x_test)
    #np.save(save_dir+'/y_predict.npy',y_predict)
    #np.savetxt(save_dir+'/y_predict.txt', y_predict)
    f_record.write(model_path)
    f_record.write('\n')
    '''
    layer_gru = K.function([model.layers[0].input], [model.layers[2].output])
    layer_cnn = K.function([model.layers[0].input], [model.layers[6].output])

    #search index of gene_pair
    pair_index=list(pair_test).index('MCM2,LIG1')
    inout_visual=x_test[pair_index]
    inout_visual=np.expand_dims(inout_visual,axis=0)

    gru_output = layer_gru([inout_visual])[0][0]  # 只修改input_image
    cnn_output = layer_cnn([inout_visual])[0][0]

    #write to xlsx
    f = openpyxl.Workbook()  # 创建工作簿
    cur_title = pair_test[pair_index] + ',' + str(y_test[pair_index])
    sheet1 = f.create_sheet(title=cur_title+'-gru', index=0)  # 创建sheet
    for row in gru_output:
        sheet1.append(list(row))
    f.save('E:/Papers/20201109-LEAP/LEAP-CNN/feature-map/L-500-MCM2-LIG1-1.xlsx')  # 保存文件
    f.close()
    '''



    output_predict = pair_test.copy()
    file = open(save_dir + '/fold'+str(fold_index)+'_y_predict.txt', 'w')
    output=''
    for index_y_predict in range(len(y_predict)):
        tf,target=output_predict[index_y_predict].split(',')
        output=output+tf+'\t'+target+'\t'+str(y_predict[index_y_predict][0])+'\n'
    file.write(output)
    file.close()

    return y_test,y_predict

def continuousToClassification(sourcedata,threshold):
    result=sourcedata.copy()
    for i in range(len(sourcedata)):
        if sourcedata[i]<threshold:
            result[i]=0
        else:
            result[i] = 1
    return result

def estimation(matrix_path, model_path, save_dir, f_record,fold_index):
    y_test, y_predict = predict(matrix_path, model_path, save_dir,fold_index)

    y_predict=y_predict[:,0].tolist()
    y_test=y_test.tolist()
    #index of sorted array(from high to low)
    map_index=np.argsort(-np.array(y_predict))
    #rank_y_predict=y_predict.sort(reverse=True)[0:279]
    binary_y_predict=np.zeros(len(y_predict))
    true_positive=0
    for i in y_test:
        if i == 1:
            true_positive+=1
    density = true_positive / len(y_test)
    print(str(len(y_test)) + ' edges in test set.')
    print(str(true_positive)+' positive edges in test set.')
    print('Density=' + str(density))
    for i in range(true_positive):
        binary_y_predict[map_index[i]]=1
    y_predict_classification=binary_y_predict



    #y_predict_classification = continuousToClassification(y_predict, 0.5)
    ############################Calculate standards#####################################################
    table_head = 'EPR\tAUPRC\taccuracy\tprecision\trecall\tf1-score\tAUC\tAUPR'
    print(table_head)
    f_record.write(table_head + '\n')

    array_y_test=np.array(y_test)
    accuracy= metrics.accuracy_score(array_y_test, y_predict_classification)
    precision= metrics.precision_score(array_y_test, y_predict_classification,pos_label=1)
    recall = metrics.recall_score(array_y_test, y_predict_classification,pos_label=1)
    f1 = metrics.f1_score(array_y_test, y_predict_classification)

    #precision=TP/（TP+FP）
    #recall = TP / (TP + FN)
    fpr, tpr, _ = metrics.roc_curve(y_test, y_predict)
    auc = metrics.auc(fpr, tpr)

    list_precision, list_recall, _ = metrics.precision_recall_curve(y_test, y_predict)
    aupr = metrics.auc(list_recall, list_precision)

    single_class_result = str(round(precision / density, 6)) + '\t' + str(round(aupr / density, 6)) + '\t' + str(
        round(accuracy, 6)) + '\t' + str(
        round(precision, 6)) + '\t' + str(round(recall, 6)) + '\t' + str(round(f1, 6)) + '\t' + str(
        round(auc, 6)) + '\t' + str(round(aupr, 6))
    print(single_class_result)
    f_record.write(single_class_result + '\n')
    ############################Plot ROC#####################################################
    plt.figure()
    colors = itertools.cycle(['aqua', 'darkorange', 'cornflowerblue'])
    plt.plot(fpr, tpr, label='ROC curve(area = {})'.format(auc))

    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC curve')
    plt.legend(loc="lower right")
    plt.savefig(save_dir + '/fold'+str(fold_index)+'-ROC.pdf', bbox_inches='tight')
    # plt.show()
    plt.close()
    ##################################Plot PR######################################################
    plt.figure()
    plt.plot(list_precision, list_recall, label='PR curve(area = {})'.format(aupr))

    plt.plot([0, 1], [1, 0], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('PR curve')
    plt.legend(loc="lower right")
    plt.savefig(save_dir + '/fold'+str(fold_index)+ '-PR.pdf', bbox_inches='tight')
    # plt.show()
    plt.close()


matrix_path = 'E:/Papers/20210124-DGRNS/500genes/mHSC-E-Nonspecific-LogPearson/WindowSize441-TF5-Target5-Lag64/FullMatrix_TF'
save_dir ='E:/Papers/20210124-DGRNS/500genes/mHSC-E-Nonspecific-LogPearson/WindowSize441-TF5-Target5-Lag64/GRU128+T32-32-model/FullResult_TF'
if not os.path.isdir(save_dir):
    os.makedirs(save_dir)
f_record = open(save_dir + '/record.txt', 'w')
for index_fold in range(0,3):
    #model_path = 'DREAM4_Models_Ave_F/InsilicoSize100_1/1saved_models_T_32-32-64-64-128-128-512_e200/best_model.hdf5'
    model_path = 'E:/Papers/20210124-DGRNS/500genes/mHSC-E-Nonspecific-LogPearson/WindowSize441-TF5-Target5-Lag64/GRU128+T32-32-model/{}'.format(index_fold)+'saved_models_e100/final_model.h5'
    #estimation(matrix_path,model_path,save_dir,f_record)
    estimation(matrix_path, model_path, save_dir, f_record,index_fold)
    print('fold{}'.format(index_fold)+' done.')
f_record.close()
