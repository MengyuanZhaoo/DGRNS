import numpy as np
import os
from dataPreprocess import *
import csv
import pandas as pd
import time

#calculate running time
start=time.clock()

# input
# rank_list_path='E:/Papers/20210124-DGRNS/1000genes/hESC-1000genes-Nonspecific-rank.csv'
gene_pair_list_path='E:/Papers/20210124-DGRNS/500genes/GenePairList/mHSC-E-Nonspecific-GPL.csv'
gene_expression_path='E:/Papers/20210124-DGRNS/scRNA-Seq/mHSC-E/ExpressionDataOrdered.csv'
gold_network_path='E:/Papers/20210124-DGRNS/Gold-network/mouse/Non-specific-ChIP-seq-network.csv'
# output
save_dir = 'E:/Papers/20210124-DGRNS/500genes/mHSC-E-Nonspecific-LogPearson/WindowSize121-TF5-Target5-Lag96/FullMatrix_TF'
if not os.path.isdir(save_dir):
    os.makedirs(save_dir)

Window_size=121
TF_Gap=5
Target_Gap=5
Max_lag=96

# Load gene expression data
origin_expression_record,cells=get_normalized_expression_data(gene_expression_path)


# Load unique_gene_list
# f_rank = open(rank_list_path)
# unique_gene_list=[]
# for single in csv.reader(f_rank):
#     unique_gene_list.append(single[0])

# Load gold_pair_record
all_gene_list=[]
gold_pair_record={}
f_genePairList=open(gene_pair_list_path)### read the gene pair and label file


for single_pair in list(csv.reader(f_genePairList))[1:]:
    if single_pair[2]=='1':
        if single_pair[0] not in gold_pair_record:
            gold_pair_record[single_pair[0]]=[single_pair[1]]
        else:
            gold_pair_record[single_pair[0]].append(single_pair[1])
        # count all genes in gold edges
        if single_pair[0] not in all_gene_list:
            all_gene_list.append(single_pair[0])
        if single_pair[1] not in all_gene_list:
            all_gene_list.append(single_pair[1])
f_genePairList.close()
# print dataset statistics
print('All genes:'+str(len(all_gene_list)))
print('TFs:'+str(len(gold_pair_record.keys())))


# #control gene-number by means of all_gene_list
# gene_control=100
# for single_pair in list(csv.reader(f_genePairList))[1:]:
#     if len(all_gene_list)<gene_control:
#         if single_pair[2]=='1':
#             if single_pair[0] not in gold_pair_record:
#                 gold_pair_record[single_pair[0]]=[single_pair[1]]
#             else:
#                 gold_pair_record[single_pair[0]].append(single_pair[1])
#             # count all genes in gold edges
#             if single_pair[0] not in all_gene_list:
#                 all_gene_list.append(single_pair[0])
#             if single_pair[1] not in all_gene_list:
#                 all_gene_list.append(single_pair[1])
#     else:
#         break
# f_genePairList.close()
# # print dataset statistics
# print('All genes:'+str(len(all_gene_list)))
# print('TFs:'+str(len(gold_pair_record.keys())))

# Generate Pearson matrix
label_list=[]
pair_list=[]
total_matrix=[]
num_tf=-1
num_label1=0
num_label0=0

#control cell numbers by means of timepoints
timepoints=len(cells)
# timepoints=800
for i in gold_pair_record:
    num_tf+=1
    for j in range(len(all_gene_list)):
    # for j in range(2):
        print ('Generating matrix of gene pair '+str(num_tf)+' '+str(j))
        tf_name=i
        target_name= all_gene_list[j]
        if tf_name in gold_pair_record and target_name in gold_pair_record[tf_name]:
            label=1
            num_label1+=1
        else:
            label=0
            num_label0+=1
        label_list.append(label)
        pair_list.append(tf_name + ',' + target_name)
        tf_data=origin_expression_record[tf_name]
        target_data = origin_expression_record[target_name]

        #calculate matrix of one gene pair
        pair_matrix = []
        for tf_window_left in range(0, timepoints - Window_size + 1, TF_Gap):
            if tf_window_left + Window_size + Target_Gap * (Max_lag - 1) > timepoints:
                break
            tf_window_data = tf_data[tf_window_left:tf_window_left + Window_size]
            single_tf_list = []
            tf_pd = pd.Series(tf_window_data)
            if (tf_window_data == np.zeros(Window_size)).all():
                exit('tf data error!')
                continue
            for lag in range(0, Max_lag):
                target_window_left = tf_window_left + lag * Target_Gap
                if target_window_left + Window_size > timepoints:
                    exit('Planning error!')
                target_window_data = target_data[target_window_left:target_window_left + Window_size]
                target_pd = pd.Series(target_window_data)
                # calculate PCC
                pcc = tf_pd.corr(target_pd, method="pearson")
                if np.isnan(pcc) or np.isinf(pcc):
                    single_tf_list.append(0.0)
                    # print('Replace Nan or inf with 0.')
                else:
                    single_tf_list.append(pcc)
            if pair_matrix == []:
                pair_matrix = np.array(single_tf_list).copy()
            else:
                pair_matrix = np.vstack((pair_matrix, np.array(single_tf_list)))
        total_matrix.append(pair_matrix.copy())

end=time.clock()
print('Running time:'+str(end-start))


if (len(total_matrix)>0):
    total_matrix = np.array(total_matrix)[:, :, :, np.newaxis]
else:
    exit('Save error.')
np.save(save_dir +'/matrix.npy', total_matrix)
np.save(save_dir+'/label.npy', np.array(label_list))
np.save(save_dir+'/gene_pair.npy', np.array(pair_list))
print('PCC matrix generation finish.')
print('Positive edges:'+str(num_label1))
print('Negative edges:'+str(num_label0))
print('Density='+str(num_label1/(num_label1+num_label0)))
